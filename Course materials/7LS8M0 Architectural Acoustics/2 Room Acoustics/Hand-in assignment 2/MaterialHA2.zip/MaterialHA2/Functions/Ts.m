function [Ts] = Ts(FiltRIR,fs)
%% [Ts] = Ts(FiltRIR,fs)
% This function calculates the Centre Time metric (Ts) from a room impulse 
% response (RIR).
%
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% FRIR  : (Filtered) Room Impulse response (Pa) [Nx1].
% fs    : Sampling frequency of the (Filtered) RIR signal (Hz) [Scalar].
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Ts : Centre Time (msec) [Scalar]
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Checking that the signal is a column vector.
if iscolumn(FiltRIR)
    FiltRIR = FiltRIR(:);
else
    FiltRIR = FiltRIR';
end

% Time vector of the FiltRIR
TimeVectFiltRIR = ... ;

% Checking that the time-vector is a column vector.
if iscolumn(TimeVectFiltRIR)
    TimeVectFiltRIR = TimeVectFiltRIR(:);
else
    TimeVectFiltRIR = TimeVectFiltRIR';
end

% FiltRIR squared.
FiltRIRSq = ... ;

%% Computation of the Ts

% =========================================================================
% Recall 1: Integral in Continuous Domain --> Sum in Discrete Domain.
% Recall 2: MATLAB indicies start from 1 and not from 0.
% Recall 3: Integral limits are ''associated'' to positions of the values.
% =========================================================================

% Calculation of the Ts nominator.
NominatorTs = ... ; 

% Calculation of the Ts denominator.
DenominatorTs = ... ; 

% Calculation of the Ts.
Ts = ... ;

end

