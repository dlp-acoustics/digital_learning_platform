function [T30] = RTLinFit(EDC,fs,RIRNum,octBand,plt)
%% [RevTime] = RTLinFit(EDC,fs,RIRNum,octBand,plt)
% This function estimates the reverberation time using a linear fitting
% extrapolation based on an interpolation in the range under consideration. 
% Also, it returns a figure including the interpolated ponts, the EDC, as
% well as the Reverberation time (T30). Note: The RIRNum and octBand
% arguments are used in ploting. 
%
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments:
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% EDC     : Truncated energy time curve in dBs [1xN or Nx1].
% fs      : Sampling frequency in Hz [Scalar].
% RIRNum  : Assign the number of RIR (e.g., 1, 2, or 3) [Scalar].
% octBand : Octave band of the filtered EDC (e.g., 125, 250, ...) [Scalar].
% plt     : Activation of plot. 1 = Yes and others = No [Scalar].
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments:
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% T30  : Estimate reverberation time (T30) in sec [Scalar].
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Definition of the upper and lower levels in dBs.
L1 = -5;
L2 = -35;

% Compute the time vector of the EDC.
timeVector = ... ;

% Find the position (index) of the EDC level which is close to L1 level.
idxL1 = ... ;

% Find the position (index) of the EDC level which is close to L2 level.
idxL2 = ... ;

% Fit a first order polynomial [y = at + b], using the polyfit function.
% This function returns the coefficients a and b. Check: help polyfit
% =========================================================================
% Polyfit Function Notes: 
% =========================================================================
% Input argument 1: Values of the time-vector, corresponding to the posi-
%                   tions from L1 level until L2 level in EDC. 
% Input argument 2: Values of the EDC, corresponding to the positions from
%                   L1 level until L2 level in EDC. 
% Input argument 3: Order of the fitted polynomial.
% Ouput Argument 1: Coefficients of the fitted polynomial.
% =========================================================================

% Estimation of the coefficients (i.e., a & b) of a first order polynomial.
[Coefs,~] = ... ;

% Extrapolate fitting line to -60dB, estimating T30 (i.e., Expression (3)).
RevTime = ... ;

%% Plot
if plt == 1
    
    figure()
    plot(timeVector,real(EDC),'color','b','linewidth',1.8)
    hold on
    plot(timeVector,Coefs(1)*(timeVector)+Coefs(2),'color','r' ,...
        'linewidth',2)
    plot(timeVector(idxL1),real(EDC(idxL1)),'o','linewidth',2)
    plot(timeVector(idxL2),real(EDC(idxL2)),'o','linewidth',2)
    line([T30 T30],[-100 0],'LineStyle','--','linewidth',2);
    ylabel('Normalized Magnitude (dB)')
    xlabel('Time (s)')
    legend('EDC','Line Fitting','Upper Point', 'Lower Point', ...
        'Estimate T_{30}')
    set(gca,'fontsize',18)
    title(['[RIR: ' num2str(RIRNum) ', ' 'fc = ' num2str(octBand) 'Hz]' ...
        ' T_{30} = ' num2str(round(T30,2)) ' sec'])
    grid on
    ylim([-100 0])
    
end

end

