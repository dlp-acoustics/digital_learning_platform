function [C50dB,C80dB] = C5080(FiltRIR,fs)
%% [C50dB,C80dB] = C5080(FiltRIR,fs)
% This function calculates the clarity for speech and music from a room
% impulse response (RIR).
%
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% FRIR  : (Filtered) Room Impulse response (Pa) [Nx1].
% fs    : Sampling frequency of the (Filtered) RIR signal (Hz) [Scalar].
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% C50dB : Clarity for speech (dB) [Scalar]
% C80dB : Clarity for music (dB) [Scalar]
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Checking that the signal is a column vector.
if iscolumn(FiltRIR)
    FiltRIR = FiltRIR(:);
else
    FiltRIR = FiltRIR';
end

% Time vector of the FiltRIR
TimeVectFiltRIR = ... ;

% Times under consideration in mileseconds.
Time50ms = 50e-3; 
Time80ms = 80e-3;

% Find the positions (indeces) of the values close to Time50ms and Time80ms
% in the time vector.
iTime50msFiltRIR = ... ;
iTime80msFiltRIR = ... ;

%% Computation of the C50 and C80

% =========================================================================
% Recall 1: Integral in Continuous Domain --> Sum in Discrete Domain.
% Recall 2: MATLAB indicies start from 1 and not from 0.
% Recall 3: Integral limits are ''associated'' to positions of the values.
% =========================================================================

% FiltRIR squared.
FiltRIRSq = ... ;

% Calculation of the C50 nominator with respect to the integral limits.
nominatorC50   = ... ;

% Calculation of the C50 denominator with respect to the integral limits.
denominatorC50 = ... ;

% Calculation of the C50 with respect to the Expression (4) in guideline.
C50dB = ... ;

% Calculation of the C80 nominator with respect to the integral limits.
nominatorC80   = ... ;

% Calculation of the C80 denominator with respect to the integral limits.
denominatorC80 = ... ;

% Calculation of the C80 with respect to the Expression (4) in guideline.
C80dB = ... ;

end

