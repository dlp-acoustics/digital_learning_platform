function [EDC,EDCtimeVector] = EDC(RIR,trd,fs)
%% [EDC,EDCtimeVector] = EDC(RIR,trd,fs)
% This function calculates the Energy Decay Curve (EDC) of the truncated
% Room Impulse Response (RIR). This function calculates one EDC per time.
%
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% RIR2          : Room Impulse response (Pa).
% trd           : Truncation time in seconds (sec).
% fs            : Sampling frequency of the RIR signal.
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% EDC           : Energy decay curve of the truncated signal (dB).
% EDCTimeVector : Time vector of the EDC (sec).
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Checking that the signal is a column vector.
if iscolumn(RIR)
    RIR = RIR(:);
else
    RIR = RIR';
end

% Calculation of the wanted length of the truncated RIR (Samples).
durationSamples = round(...,1) ;

% Import the truncated signal into a new variable.
RIRTrd = RIR(...);

% Truncated signal squared.
RIRTrd = ...;

%% Calculation of the Schreider Integral [Expression (2), page 3]

% =========================================================================
% Recall: Integral in Continuous Domain --> Sum in Discrete Domain.
% =========================================================================

% Calculation of the numerator, using the cumsum function.
Numerator = cumsum(RIRTrd,1);

% Calculation of the denominator, using the sum function.
Denominator = ...;

% Fraction term into the Expression (2).
IntTerms = ...;

% Calculation of the EDC.
EDC = ...;

% Calculation of the time-vector of the EDC.
EDCtimeVector = ...;

end

