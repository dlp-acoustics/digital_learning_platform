%% 1/1-Octave Band Filtering Approach

clear all
close all
clc

%**************************************************************************
%**************************************************************************
% Before you continue reading the script please listen to the three impulse
% responses. They are wav files so you can listen to them with Media Player
% First listen to  'RIRdist1.wav' then 'RIRdist2.wav' and finally the 
% 'RIRdist3.wav' in order to hear the level differences due to the 
% different measurement locations.
%**************************************************************************
%**************************************************************************

% =========================================================================
% Time Domain
% =========================================================================

[RIR1,fs] = audioread('RIRdist1.wav');
[RIR2,~]  = audioread('RIRdist2.wav');
[RIR3,~]  = audioread('RIRdist3.wav');

% Time Vector
dt = 1/fs;        % Sampling period
N  = length(RIR1); % Total number of samples. Equal for all the responses.
t  = (0:N-1)*dt;   % Time vector (all the responses have the same length)


% ------------------------ Start of Filtering code ------------------------
% 1/1-Octave frequency bands definitions
fc = [125 500]; % Center frequencies
f_l = 2.^(-1/2).*fc; % Lower limit
f_h = 2.^(1/2).*fc;  % Upper limit

order = 3; % 2nd order Butterworth filter

fnq = fs/2; % Nyquist frequency

% You have to repeat the next steps in a for-loop to do the filtering for
% each 1/1-octave frequency band.

for n=1:length(fc)
    
    % Butterworth bandpass non-dimensional frequency
    Wn = [f_l(n)/fnq f_h(n)/fnq];
    
    % Filters construction
    [b,a] = butter(order,Wn,'bandpass'); 

    % Filtering of the time signals.
    FiltRIR1(n,:) = filtfilt(b,a,RIR1); 
    % =====================================================================
    % Explanation: 
    % =====================================================================
    % Time-signal filtered for the 125Hz and 500Hz 1/1-octave centre
    % frequency bands. The FiltRIR1 is basically the variable ho(t) in the
    % Expression (1) at the page 3 in the HA2 guideline). FiltRIR1 is a 
    % MATRIX (not a vector), where the filterd-time signal for the octave 
    % band 125Hz is stored on the first row of the matrix and the 500Hz on 
    % the second row. Note: Check the matrix for better understanding
    % (double click on FiltRIR1 on the Workspace window).
    % =====================================================================
end

%------------------------- End of Filtering Code --------------------------

% =========================================================================
% Frequency domain
% =========================================================================

% Frequency Vector
df = fs/N;  % Frequency spacing
f  = [0:length(RIR1)-1].*(fs/length(RIR1)); % Frequency vector 

% Frequency responses of the octave band filtered RIR 1
fft1 = abs(fft(FiltRIR1(1,:)));
fft2 = abs(fft(FiltRIR1(2,:)));
fft3 = abs(fft(RIR1));

% =========================================================================
% Plots
% =========================================================================

% Figures to demonstrate the effect of the filtering
f_l= round(f_l);
f_h = round(f_h);

figure(1)
plot(t,RIR1)
title('Original RIR1','linewidth',2)
xlabel('Time [sec]')
ylabel('Amplitude [Pa]')
set(gca,'fontsize',18)
xlim([0 0.25])
grid on

figure(2)
subplot(2,1,1)
plot(t,FiltRIR1(1,:),'b','linewidth',2)
title('Filtered RIR 1 with bandpass frequency 125Hz')
xlabel('Time [sec]')
ylabel('Amplitude [Pa]')
set(gca,'fontsize',18)
ylim([-0.1 0.1])
xlim([0 0.25])
subplot(2,1,2)
plot(t,FiltRIR1(2,:),'r','linewidth',2)
title('Filtered RIR1 with bandpass frequency 500Hz')
xlabel('Time [sec]')
ylabel('Amplitude [Pa]')
set(gca,'fontsize',18)
ylim([-0.1 0.1])
xlim([0 0.25])

figure(3)
plot(f,10*log10(2*abs(fft1)),'linewidth',2)
hold on
plot(f,10*log10(2*abs(fft2)),'linewidth',2)
hold on
plot(f,10*log10(2*abs(fft3)),'linewidth',2)
title('Frequency Response of Octave Band Filtered RIR 1 ')
legend('125Hz Octave','500Hz Octave','RIR 1','location','southeast')
xlabel('Frequency [Hz]')
ylabel('Amplitude [dB]')
set(gca,'fontsize',18)
set(gca,'XTick',[f_l(1) fc(1) f_h(1) f_l(2) fc(2) f_h(2)])
set(gca,'XTickLabel',[f_l(1) fc(1) f_h(1) f_l(2) fc(2) f_h(2)])
ylim([-80 20])
xlim([0 1000])
grid on







