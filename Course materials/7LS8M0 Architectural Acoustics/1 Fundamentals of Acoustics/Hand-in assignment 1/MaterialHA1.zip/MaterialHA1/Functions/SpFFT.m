function [outputArg1,outputArg2] = SpFFT(inputArg1,inputArg2)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% inputArg1 :  
% inputArg2 :
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% outputArg1 :  
% outputArg2 :
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

outputArg1 = inputArg1;
outputArg2 = inputArg2;

end

