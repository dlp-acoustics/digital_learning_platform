function [TimeVect, SinWave] = SinGen(A, f, phi, T, fs)
%
% This function is used such,
% [TimeVect, SinWave] = SinGen(A, f, phi, T, fs)
%
% This function generates sinusoidal signal, providing its time vectors.
%
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% A   : Amplitude (-)
% f   : Frequency (Hz)
% phi : Phase (rads)
% T   : Total duration (s)
% fs  : Sampling frequency (Hz)
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% TimeVect: Time vector (s)
% SinWave : Sinusoidal wave (-)
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Definition of the time-vector 
% Time-vector starts from 0 to T with respect to a sampling period as step.

step = ...;
    
TimeVect = ...;

% Signal Generation
% Implement the expression (1) in the page 2 of the guideline

SinWave = ...;

end

