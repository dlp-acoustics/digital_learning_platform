% FFT Example Supplementary Approach

clear all % Clear all the data
close all % Close all the figures
clc       % Clear the command window

% Definition of a sinusoid signal.

fs = 4000;           % Sampling Frequency (Hz)
T = 4;               % Total Duration of the sine wave (s)
f = 200;             % Frequency of the sine wave (Hz)
w = 2*pi*f;          % Angular frequency (rad/sec)
Amp = 1;             % Amplitude of the sine wave
t = 0:1/fs:T-1/fs;   % Time series vector.
wave = Amp*sin(w*t); % Generation of sine wave (i.e. y(t)=Asin(ωt))

% Moving from Time Domain to Frequency Domain

% The Fourier Transform of a real-valued signal is computed via the Fast
% Fourier Transform (FFT) function, returning the signal in the frequency
% domain, corresponding to a complex-valued signal.
Fwave = fft(wave);

% By dividing the FFT signal with respect to the length of the real-valued 
% signal, a physical meaning in the amplitude of the complex-valued signal 
% is provided. 
Fwave = Fwave/length(wave); 

% Since the FFT returns a complex-valued signal, information related to the
% amplitude and the phase are included. Hence, for extracting the spectrum
% of the complex-valued signal, the absolute value of the FFT signal is
% used, corresponding to the amplitude of the signal's components at 
% specific frequencies.
abs_fft=abs(Fwave);

% Similar to the Time Domain, the Frequency Vector is needed to be
% constructed. Firstly, the period of the used signal is calculated such,
Ts = length(Fwave)/fs;

% Then, the distance between two frequencies can be calculated such,
df = 1/Ts;

% The last step is the calculation of the frequency vector. At this point
% it should be noted that the FFT function returns ONLY the positive
% components, starting from 0 Hz (i.e., DC offset) to 2*fs/2 = fs Hz.
fvector = 0:df:fs-df;

% Plot of the Amplitude Spectrum in the whole frequency range.
figure(1)
plot(fvector,abs_fft,'linewidth',2) 
hold on
plot([fs/2 fs/2],[0 1],'--','linewidth',2)
title('Full Amplitude Spectrum of y(t)')
legend('FFT components','fs/2')
ylabel('Amplitude (-)')
xlabel('Frequency (Hz)')
set(gca,'fontsize',15)
grid on
ylim([0 1])

% As it can be seen from the Figure (1), two "peaks" are presented, where
% the second peak corresponds to a mirroring of the component located in 
% the frequency range [0,fs/2] to the frequency range [fs/2,fs] (i.e., out 
% of the Nyquist boundary). This is a consequence of the FFT in MATLAB,
% where FFT function sets a DC offset, rather than ranging from -∞ to +∞.

% Recalling that the sampling frequency should be higher than 2fmax, the 
% maximimum frequency of a signal corresponds to Nyquist frequency. Hence, 
% the frequency range [0,fs/2] is ONLY needed, neglecting [fs/2,fs].

% Focusing ONLY on the first half of the spectrum, the amplitude spectrum
% is needed to be multiplied by a factor of 2, keeping the energy the same.

% Plot of the single-sided amplitude spectrum in the half frequency range
figure(2)
plot(fvector(1:length(Fwave)/2),2*abs_fft(1:length(Fwave)/2),'linewidth',2) 
set(gca,'fontsize',15)
title('Single-Sided Amplitude Spectrum of y(t)') 
ylabel('Amplitue (-)')
xlabel('Frequency (Hz)')
ylim([0 1])
grid on

% Mathematical Approach

% Following the mathematics, it can be seen that the components of the
% complex-valued signals are located in both negative and positive axes.
% The DC-offset in the FFT can be removed using the function fftshift,
% providing the complex-valued signal's components to the range [-fs/2,0]
% and [0,fs/2].
Fwave_shift = fftshift(Fwave);

% Similar to the previous approach, the frequency vector is needed to be
% calculated, since the range is different.
fvector_shift = -fs/2:df:fs/2-df;

figure(3)
plot(fvector_shift, abs(Fwave_shift), 'linewidth', 2)
set(gca,'fontsize',15)
title('Full Amplitude Spectrum of y(t) [Shiffted]')
ylabel('Amplitude (-)')
xlabel('Frequency (Hz)')
ylim([0 1])
grid on

% The reason of excluding the negative frequency components is related to
% the fact that they do not provide a physical meaning. By considering that
% the frequency is inversly propotional to period and therefore to time,
% negative time does not physically exist.


