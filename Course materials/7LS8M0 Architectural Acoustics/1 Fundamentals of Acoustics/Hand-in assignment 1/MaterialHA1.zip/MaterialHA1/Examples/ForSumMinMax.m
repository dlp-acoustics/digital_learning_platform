% for-loop, find-function, and max/min-functions examples

clear all
close all
clc

%% For-loop Examples: Use the for-loop to calculate the Parabolic function

% Definition of the l vector
l = -15:15;

% Calculation of the parabolic function for each value of l-vector
for n=1:length(l)
  
  k(n)=l(n)^2+8;
    
end

% Plotting of the Parabolic function.
figure
plot(l,k,'linewidth',2)
set(gca, 'fontsize', 18)
title('Parabola: k=l^2+8')
xlabel('l')
ylabel('k')    
xlim([min(l) max(l)])
ylim([min(k) max(k)])
grid on

%% Find and max & min indice and sum up
clear all; close all; clc

% Task: Sum up the numbers of the "op" vector which are larger than -5 and 
% smaller than 5;

% op-vector has values from -12 until 15 with a step of 0.62. 

op = -12:0.62:15; % Green line in the plot
 
% Firstly, we find the locations (indeces) of the values that are larger 
% than or equal to -5, corresponding to the values in the range [-5,15].

LargEqMinus5 = find(op>=-5); % Blue dashed lines with 'o' in the plot

% Then the minimum location (i.e., corresponding to the minimum value) is
% extracted using the min function, corresponding to first position at 
% which op >= -5.

LowLim =  min(LargEqMinus5); % Left black line in the plot.

% The same procedure is followed by finding the values that are smaller 
% than or equal to 5, corresponding to the values in the range [-12,5].

SmalEq5 = find(op<=5); % Red dotted line with 'o' in the plot.

% Then, it is returned the index of the last value which is smaller than or
% equal to 5.
UpLim = max(SmalEq5); % Right black line in the plot.
 
% Values in the op vector between the -5 and 5.

OpRange = op(LowLim:UpLim); % Black 'o' the plot.

% Finally, sum up the values of the "op" vector which are larger than -5 
% and smaller than 5.

ad = sum(OpRange); % 

% A graphical representation of the latter example is plotted.
figure(2)
SamplesVectors = [1:length(op)];
plot(SamplesVectors, op, 'color', 'g','linewidth',2)
hold on
stem(SamplesVectors(min(LargEqMinus5):end), op(LargEqMinus5),'--',...
    'color', 'b', 'linewidth',2)
stem(SamplesVectors(1:max(SmalEq5)), op(SmalEq5),':','color', 'r',...
    'linewidth',2)
plot(SamplesVectors(min(LargEqMinus5)+1:max(SmalEq5)-1),...
    op(min(LargEqMinus5)+1:max(SmalEq5)-1),'h','color','k','linewidth',2)
stem(SamplesVectors(min(LargEqMinus5)), op(LowLim),'h','color','k',...
    'linewidth',2)
stem(SamplesVectors(max(SmalEq5)), op(UpLim),'s','color','k',...
    'linewidth',2)
legend('op \in [-12,15]','op \in [-5,15]','op \in [-12,5]',...
    'op \in (-5,5)','location','northwest')
txtLow = ' \leftarrow LowLim';
text(SamplesVectors(min(LargEqMinus5)), op(LowLim),txtLow,'fontsize',15)
txtUp = 'UpLim \rightarrow   ';
text(SamplesVectors(max(SmalEq5)), op(UpLim),txtUp,'fontsize',15,...
    'HorizontalAlignment','right')
title('Finding the Values in a Considered Area')
xlabel('index')
ylabel('op = op(index)')
set(gca,'fontsize',18)
xlim([min(SamplesVectors) max(SamplesVectors)])
ylim([min(op) max(op)])
grid on


