function [CFC,Cufd,PwV500] = FitRefCurv(fc,ISOsud,refC,MesC,Tstps,stp,plt)
%
% [CFC,Cufd,PwV500] = FitRefCurv(fc,ISOsud,refC,MesC,TStps,stp,plt)
%
% This function fits the reference curve into the measured data, returning
% the correct fitted curve, its unfavourable deviations with measured 
% curve, and the weight sound reduction reduction or impact sound level
% value at 500Hz. Also, a number of plots is returned, showing the fitting
% methodology and its metric of evaluation.
%
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Input Arguments:
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% fc     : Central 1/3-Octave Frequency Bands [1xN](Hz)
% ISOsud : Sum of Unfavourable Deviations according to ISO [i.e., 32dB](dB)
% refC   : Refurence curve per 1/3-Octave Frequency Band [1xN] (dB) 
% MesC   : Measured curve per 1/3-Octave Frequency Band [1xN] (dB)
% Tstps  : Total Number of Steps [1x1] (dB)
% stp    : Increment Step [i.e., +1 = Up, -1 = Down] [1x1]
% plt    : Returning of plots (i.e., 1 = Yes, 0 = No) [1x1]
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% Output Arguments:
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% CFC    : Correct Fitted Reference Curve [1xN] (dB)
% ufds   : Unfavourable Deviations of the CFC with MesC [1xN] (dB)
% PwV500 : Prime weighted value (R'w ot L'n) at 500Hz on CFC [1x1] (dB)
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Define the number of steps starting from 1 till the total number of steps
steps = ...;

NumStep = length(steps);
fcs     = length(fc);

% Zero-padding the defined variables.
FitCurves  = zeros(NumStep,fcs); % Fitting reference curve per step.
CondCurves = zeros(NumStep,fcs); % Conditional-based curves [see eq(4)].
ufds       = zeros(NumStep,fcs); % Unfavorable deviations per step.
Sufds      = zeros(NumStep,1);   % Sum Unfavorable deviations per step.

% Calculation of fitted curves and their unfavorable deviations per step.
for j = ...
     
    % Computation of the fitted curves
    FitCurves(j,:)= ...; 

    % In each fitted curve, keep the values per frequency band that fulfill
    % the condition for the the equation (4) in guideline at page 4
    for ...
        
        % If the condition is fulfilled:
        if ...
            
            % Keep: The corresponding value.
            CondCurves(j,i) = ...;
            
        else
            
            % Assign: The component that DOES NOT fulfill the condition 
            % with NaN (i.e., Not a Number = undefined numeric result).
            CondCurves(j,i) = NaN;
        end 
        
    end
    
    % Calculation of the differences between the fitted and measured curve.
    % [Note: The computations with NaN value are NaN (e.g., 1+NaN = NaN).] 
    ufds(j,:) = ...;
    
    % Calculation of the sum of the unfavorable deviations,using the 
    % Equation (4) in the guideline in the page 4. [Note: Use the nansum
    % build-in function, treating NaNs as missing values. On this way, only
    % the unfavorable deviations are considered, corresponding to the
    % components of the fitted and measured curves which fullfill the
    % condition in the Equation (4).]
    Sufds(j) = ...;
            
end

% Extraction of the correct fitted curve, corresponding to the fact that 
% the sum of unfavorable deviations to be as large as possible, but no more
% than 32dB.

if stp == -1 % Corresponding to -1dB
    
    % Find the correct fitted curve, when the step is -1.
    idxFCurve = ...;

    
elseif stp == +1 % Corresponding to +1dB
    
    % Find the correct fitted curve, when the step is +1.
    idxFCurve = ...;
    
end 

% Extract the correct fitted curve, which meets the ISO condition.
CFC = ...;
    
% Extract the unfavorable deviations of the correct fitted curve.
Cufd = ...;
    
% Extract the sum unfavorable deviations of the correct fitted curve.
CSufd = ...;

% Prime Level value at 500Hz in the corrected fitted curve.
PwV500 = ...;
    
%% ---------------------------- Plotting ----------------------------------

if plt == 1 
    h1=figure();
    if sum(refC) == 788
        subplot(2,2,1)
        plot(fc,refC,'color','b','linewidth',2)
        hold on
        plot(fc,MesC,'color','k','linewidth',2)
        plot(fc,CondCurves,'linewidth',2)
        title('Identification of Unfavourable Deviation per 1dB Increment')
        xlabel('frequency (Hz)')
        ylabel('Sound Reduction Index (dB)')
        set(gca,'fontsize',18)
        ylim([0 90])
        grid on
    elseif sum(refC) == 907
        subplot(2,2,1)
        plot(fc,refC,'color','b','linewidth',2)
        hold on
        plot(fc,MesC,'color','k','linewidth',2)
        plot(fc,CondCurves,'linewidth',2)
        title('Identification of Unfavourable Deviation per 1dB Increment')
        xlabel('frequency (Hz)')
        ylabel('Impact Sound Level (dB)')
        set(gca,'fontsize',18)
        ylim([0 90])
        grid on
    else
        subplot(2,2,1)
        plot(fc,refC,'color','b','linewidth',2)
        hold on
        plot(fc,MesC,'color','k','linewidth',2)
        plot(fc,CondCurves,'linewidth',2)
        title('Identification of Unfavourable Deviation per 1dB Increment')
        xlabel('frequency (Hz)')
        ylabel('Level (dB)')
        set(gca,'fontsize',18)
        ylim([0 90])
        grid on
    end
    subplot(2,2,2)
    stem(steps,Sufds,'linewidth',2)
    hold on
    plot([1:length(steps)],ISOsud*ones(1,length(steps)),'linewidth',2)
    legend('SumPerStep','RefLimit','location','northeast')
    xlabel('Increment Step (dB)')
    ylabel('Level (dB)')
    title('Unfavourable Deviation Sum per 1dB Increment Step')
    set(gca,'fontsize',18)
    grid on
    subplot(2,2,3)
    if sum(refC) == 788
        plot(fc,refC,'color','b','linewidth',2)
        hold on
        plot(fc,CFC,'color','r','linewidth',2)
        plot(fc,MesC,'color','k','linewidth',2)
        title(['Weighted Sound Redunction Indexes (R^{\prime}_w = ',...
            num2str(CFC(8)) ,'dB)'])
        legend('Ref. Curve','Fit. Curve', 'R','location','northeast')
        xlabel('frequency (Hz)')
        ylabel('Sound Reduction Index (dB)')
        set(gca,'fontsize',18)
        ylim([0 90])
        grid on
    elseif sum(refC) == 907
        plot(fc,refC,'color','b','linewidth',2)
        hold on
        plot(fc,CFC,'color','r','linewidth',2)
        plot(fc,MesC,'color','k','linewidth',2)
        title(['Weighted Impact Sound Level (L^{\prime}_n = ',...
            num2str(CFC(8)) ,'dB)'])
        legend('Ref. Curve','Fit. Curve', 'L_n','location','northeast')
        xlabel('frequency (Hz)')
        ylabel('Impact Sound Level (dB)')
        set(gca,'fontsize',18)
        ylim([0 90])
        grid on
    else
        plot(fc,refC,'color','b','linewidth',2)
        hold on
        plot(fc,CFC,'color','r','linewidth',2)
        plot(fc,MesC,'color','k','linewidth',2)
        title(['Weighted Level (L^{\prime} = ', num2str(CFC(8)),'dB)'])
        legend('Ref. Curve','Fit. Curve', 'L','location','northeast')
        xlabel('frequency (Hz)')
        ylabel('Sound Level (dB)')
        set(gca,'fontsize',18)
        ylim([0 90])
        grid on
    end
    subplot(2,2,4)
    bar(Cufd)
    xlabel('Frequency Band (Hz)')
    ylabel('Pressure Level  (dB)')
    title(['Unfavourable Deviation Sum: ' num2str(round(CSufd,2)) 'dB',...
        '(<',num2str(ISOsud),'dB)'])
    set(gca, 'fontsize', 18)
    set(gca, 'XTick', [1:16])
    set(gca,'XTickLabel', fc')
    ylim([0 max(Cufd)])
    xtickangle(90)
    grid on
    set(h1,'Position',[500 700 1400 700])
    
end

end

